<div class="col-4 col-md-3 col-custom-item5 residences show all">
					<a href="images/gallery01-01.jpg" class="tt-gallery"><div class="gallery__icon"></div><img src="images/gallery01-01.jpg" alt=""></a>
				</div>
				<div class="col-4 col-md-3 col-custom-item5 residences show all">
					<a href="images/gallery01-02.jpg" class="tt-gallery"><div class="gallery__icon"></div><img src="images/gallery01-02.jpg" alt=""></a>
				</div>
				<div class="col-4 col-md-3 col-custom-item5 residences show all">
					<a href="images/gallery01-03.jpg" class="tt-gallery"><div class="gallery__icon"></div><img src="images/gallery01-03.jpg" alt=""></a>
				</div>
				<div class="col-4 col-md-3 col-custom-item5 industrial_objects show all">
					<a href="images/gallery01-04.jpg" class="tt-gallery"><div class="gallery__icon"></div><img src="images/gallery01-04.jpg" alt=""></a>
				</div>
				<div class="col-4 col-md-3 col-custom-item5 offices show all">
					<a href="images/gallery01-05.jpg" class="tt-gallery"><div class="gallery__icon"></div><img src="images/gallery01-05.jpg" alt=""></a>
				</div>