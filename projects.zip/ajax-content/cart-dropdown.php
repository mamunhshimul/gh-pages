<div class="tt-obj__dropdown-close icon-860796"></div>
							<div class="tt-obj__title">Shopping Cart</div>
							<div class="tt-cart-list">
								<div class="tt-item">
									<a class="tt-item__remove icon-rubbish-bin-delete-button" href="#"></a>
									<div class="tt-item__img">
										<img src="images/product-01.jpg" alt="">
									</div>
									<div class="tt-item__content">
										<div class="tt-item__title"><a href="#">
											Woods WiOn 15 amps Receptacle and USB Charger
										</a></div>
										<div class="tt-item__price">
											$41.99
										</div>
									</div>
								</div>
								<div class="tt-item">
									<a class="tt-item__remove icon-rubbish-bin-delete-button" href="#"></a>
									<div class="tt-item__img">
										<img src="images/product-02.jpg" alt="">
									</div>
									<div class="tt-item__content">
										<div class="tt-item__title"><a href="#">
											Powerboss 3500 watts Gasoline Portable Generator
										</a></div>
										<div class="tt-item__price">
											<span class="new-price">$329.99</span> <span class="old-price">$342.32</span>
										</div>
									</div>
								</div>
							</div>
							<div class="tt-cart-total">
								<div class="row tt-row">
									<div class="col-auto">Total:</div>
									<div class="col-auto">$371.98</div>
								</div>
								<a class="tt-btn btn__color01" href="#">Proceed to Checkout</a>
							</div>